package sth.core;

public enum UserBehavior{
    NORMAL,
    CUMPRIDOR,
    FALTOSO;

}