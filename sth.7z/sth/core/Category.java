package sth.core;

public enum Category{
    REFERENCE,
    FICTION,
    SCITECH;
}